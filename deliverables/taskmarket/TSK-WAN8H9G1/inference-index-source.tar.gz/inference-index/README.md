# Inference Index

Inference Index is a public Next.js leaderboard and a commercial Lucid Agents API for narrow, source-linked comparisons of MLPerf Inference results. The initial release publishes one exact slice: MLPerf Inference v6.0, Closed division, `gpt-oss-120b`, Offline, default accuracy target, tokens per second.

It does not claim that one accelerator is universally fastest. The official submitted-system result is the default metric. A per-accelerator view is explicitly derived only from the source-declared accelerator count.

## Requirements

- Node.js 22.13 or later, or Bun 1.2 or later.
- No database is required.
- Payment configuration is optional. Free operations boot without it; paid operations fail closed.

## Local verification

```bash
npm ci
npm run data:verify
npm run data:verify:full
npm run type-check
npm test
```

Equivalent required commands:

```bash
bun install --frozen-lockfile
bun run type-check
bun test
bun run build
```

Start the development service with `npm run dev`; the human site is at `/` and discovery begins at `/api/agent/entrypoints`.

## Architecture

- `scripts/build-dataset.mjs` is the deterministic importer, normalizer, Zod validator, quarantine step, generator, and atomic promoter.
- `data/source-registry.json`, `data/alias-registry.json`, and `data/metric-registry.json` are reviewed policy inputs.
- `data/generated/` contains the immutable snapshot, manifest, coverage matrix, quarantine report, tombstones, and changelog.
- `lib/agent-runtime.ts` composes one server-only runtime using the pinned Lucid HTTP and payment extensions.
- `app/api/agent/**/route.ts` delegates directly to `runtime.http.handlers`; there is no parallel adapter or payment contract.
- `app/` and `components/` render the accessible editorial site.

## Agent operations

| Operation | Price | Purpose |
| --- | ---: | --- |
| `get-dataset-status` | Free | Manifest, freshness, counts, sources, exact slice IDs |
| `preview-inference-chips` | Free | Up to five verified rows |
| `rank-inference-chips` | $0.02 | Exact-slice ranking, filters, grouping, views, pagination |
| `compare-inference-chips` | $0.03 | Explicit-baseline comparison for 2–8 accelerator slugs |

See [DATA_SOURCES.md](DATA_SOURCES.md), [PAYMENTS.md](PAYMENTS.md), [UPDATE_ROLLBACK.md](UPDATE_ROLLBACK.md), [DEPLOYMENT.md](DEPLOYMENT.md), and [VERIFICATION.md](VERIFICATION.md).

## Scope and limitations

The pinned repository contains more eligible paths than the initial reviewed allowlist. V1 deliberately promotes only three gpt-oss-120b Offline systems whose identity and evidence have been reviewed. `llama3.1-8b`, `deepseek-r1`, Server, and Interactive are allowed future dimensions but are not silently merged into this slice. Open, Network, edge, vision, speech, training, marketing claims, mainnet payment, user accounts, and live scraping remain out of scope.

## Security

No private key, token, `.env`, payment credential, or unredacted deploy output belongs in this repository. Base Sepolia is the only advertised x402 network. The seller destination is public wallet metadata, not a secret.

import { createHash } from "node:crypto";
import { readFile, writeFile, mkdir, rename, rm } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { z } from "zod";

const root = process.cwd();
const argv = process.argv.slice(2);
const mode = argv[argv.indexOf("--mode") + 1] ?? "fixture";
const verify = argv.includes("--verify");
if (!new Set(["fixture", "full-source"]).has(mode)) throw new Error(`Unknown mode: ${mode}`);

const loadJson = async (relative) => JSON.parse(await readFile(path.join(root, relative), "utf8"));
const [sourceRegistry, metricRegistry, aliasRegistry] = await Promise.all([
  loadJson("data/source-registry.json"), loadJson("data/metric-registry.json"), loadJson("data/alias-registry.json"),
]);
const commit = sourceRegistry.commit;
const baseUrl = `https://github.com/${sourceRegistry.repository}/blob/${commit}`;
const sha256 = (value) => createHash("sha256").update(value).digest("hex");
const publicSource = (source) => ({
  repository: sourceRegistry.repository,
  commit,
  path: source.relative,
  url: source.url,
  sha256: source.sha256,
});
const readSource = async (relative) => {
  const raw = await readFile(path.join(root, "data/fixture-sources", relative), "utf8");
  return { relative, raw, sha256: sha256(raw), url: `${baseUrl}/${relative}` };
};
const findNumber = (raw, label) => {
  const match = raw.match(new RegExp(`^${label}:\\s*([0-9.]+)$`, "m"));
  return match ? Number(match[1]) : null;
};
const findAccuracy = (raw) => {
  const matches = [...raw.matchAll(/FINAL SCORE:\s*([0-9.]+)%/g)];
  return matches.length ? Number(matches.at(-1)[1]) : null;
};
const slugify = (value) => value.toLowerCase().replace(/\(r\)/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

const ProvenanceSchema = z.object({repository:z.string(),commit:z.string().length(40),path:z.string(),url:z.string().url(),sha256:z.string().length(64)});
const RecordSchema = z.object({
  logicalId:z.string().min(1), contentVersionId:z.string().length(64), vendor:z.string().min(1), submitter:z.string().min(1),
  systemId:z.string().min(1), systemName:z.string().min(1), acceleratorSlug:z.string().min(1), accelerator:z.string().min(1), acceleratorRaw:z.string().min(1),
  acceleratorCount:z.number().int().positive(), hostProcessor:z.string(), framework:z.string(), operatingSystem:z.string(),
  officialValue:z.number().finite().nonnegative(), derivedPerAcceleratorValue:z.number().finite().nonnegative(), samplesPerSecond:z.number().finite().nonnegative(),
  accuracy:z.number().finite().min(0).max(100), valid:z.literal(true), comparableSlice:z.record(z.string(),z.string()), provenance:z.array(ProvenanceSchema).length(3),
});

const records = [];
const quarantine = [];
const sourceManifest = [];
for (const item of sourceRegistry.systems) {
  const prefix = `closed/${item.vendor}`;
  const systemPath = `${prefix}/systems/${item.systemId}.json`;
  const resultRoot = `${prefix}/results/${item.systemId}/${sourceRegistry.workload}/${sourceRegistry.scenario}`;
  const sources = await Promise.all([
    readSource(systemPath), readSource(`${resultRoot}/performance/run_1/mlperf_log_summary.txt`), readSource(`${resultRoot}/accuracy/accuracy.txt`),
  ]);
  sourceManifest.push(...sources.map(publicSource));
  try {
    const system = JSON.parse(sources[0].raw);
    const officialValue = findNumber(sources[1].raw, "Tokens per second");
    const samplesPerSecond = findNumber(sources[1].raw, "Samples per second");
    const accuracy = findAccuracy(sources[2].raw);
    const acceleratorCount = Number(system.accelerators_per_node);
    if (!/Result is\s*:\s*VALID/.test(sources[1].raw)) throw new Error("review-required: upstream performance result is not VALID");
    if (officialValue === null || samplesPerSecond === null || accuracy === null) throw new Error("review-required: required metric or accuracy evidence is missing");
    if (!Number.isInteger(acceleratorCount) || acceleratorCount <= 0) throw new Error("review-required: accelerator count is missing or ambiguous");
    const vendor = aliasRegistry.vendors[system.submitter] ?? system.submitter;
    const accelerator = aliasRegistry.accelerators[system.accelerator_model_name] ?? system.accelerator_model_name;
    const acceleratorSlug = slugify(accelerator);
    const comparableSlice = {
      suiteRelease:sourceRegistry.suiteRelease, division:sourceRegistry.division, workload:sourceRegistry.workload,
      scenario:sourceRegistry.scenario, accuracyTarget:sourceRegistry.accuracyTarget, metricId:sourceRegistry.metricId,
      unit:metricRegistry.metrics[sourceRegistry.metricId].canonicalUnit,
    };
    const logicalId = ["mlperf-inference-v6.0","closed",item.vendor.toLowerCase(),item.systemId,sourceRegistry.workload,sourceRegistry.scenario.toLowerCase()].join("/");
    const withoutVersion = {
      logicalId, vendor, submitter:system.submitter, systemId:item.systemId, systemName:system.system_name, acceleratorSlug, accelerator,
      acceleratorRaw:system.accelerator_model_name, acceleratorCount, hostProcessor:system.host_processor_model_name ?? "",
      framework:system.framework ?? "", operatingSystem:system.operating_system ?? "", officialValue, derivedPerAcceleratorValue:officialValue/acceleratorCount,
      samplesPerSecond, accuracy, valid:true, comparableSlice, provenance:sources.map(publicSource),
    };
    const record = {...withoutVersion, contentVersionId:sha256(JSON.stringify(withoutVersion))};
    records.push(RecordSchema.parse(record));
  } catch (error) {
    quarantine.push({status:"review-required", logicalId:`mlperf-inference-v6.0/closed/${item.vendor.toLowerCase()}/${item.systemId}`, reason:error instanceof Error?error.message:String(error), sourcePaths:sources.map((source)=>source.relative)});
  }
}

for (const fixture of sourceRegistry.quarantineFixtures) {
  const [systemRaw, performanceRaw, accuracyRaw] = await Promise.all(["system.json","performance.txt","accuracy.txt"].map((file)=>readFile(path.join(root,fixture.root,file),"utf8")));
  const system = JSON.parse(systemRaw);
  const count = Number(system.accelerators_per_node);
  const valid = /Result is\s*:\s*VALID/.test(performanceRaw) && findAccuracy(accuracyRaw) !== null;
  if (!valid || !Number.isInteger(count) || count <= 0) quarantine.push({status:"review-required", logicalId:`fixture/${fixture.fixtureId}`, reason:fixture.expectedReason, sourcePaths:[`${fixture.root}/system.json`,`${fixture.root}/performance.txt`,`${fixture.root}/accuracy.txt`]});
}

records.sort((a,b)=>b.officialValue-a.officialValue||a.logicalId.localeCompare(b.logicalId));
const ranked = records.map((record,position)=>({...record,position:position+1,rank:position===0?1:(record.officialValue===records[position-1].officialValue?records.slice(0,position).filter((prior)=>prior.officialValue>record.officialValue).length+1:position+1)}));
const sliceId = "mlperf-v6.0/closed/gpt-oss-120b/offline/default-accuracy/tokens-per-second";
const datasetCore = {
  schemaVersion:"1.1.0", datasetVersion:"2026.08.27-mlperf-v6.0-gpt-oss-120b-offline.1", generatedAt:"2026-08-27T00:00:00.000Z", lastReviewedAt:"2026-08-27T00:00:00.000Z",
  freshness:{state:"current", policyDays:30}, pinnedCommit:commit,
  manifest:{repository:sourceRegistry.repository,commit,sourceFileCount:sourceManifest.length,mode:"full-source-compatible"},
  slices:[{id:sliceId,description:"Official submitted-system tokens per second for MLPerf Inference v6.0 Closed division, gpt-oss-120b, Offline scenario, default accuracy target; higher is better.",suiteRelease:sourceRegistry.suiteRelease,division:sourceRegistry.division,workload:sourceRegistry.workload,scenario:sourceRegistry.scenario,accuracyTarget:sourceRegistry.accuracyTarget,metricId:sourceRegistry.metricId,metric:metricRegistry.metrics[sourceRegistry.metricId]}],
  entities:{
    accelerators:[...new Map(ranked.map((record)=>[record.acceleratorSlug,{slug:record.acceleratorSlug,vendor:record.vendor,name:record.accelerator}])).values()],
    systems:ranked.map((record)=>({logicalId:`system/${record.vendor.toLowerCase()}/${record.systemId}`,systemId:record.systemId,acceleratorSlug:record.acceleratorSlug,acceleratorCount:record.acceleratorCount,submitter:record.submitter})),
    results:ranked.map((record)=>({logicalId:record.logicalId,contentVersionId:record.contentVersionId,sliceId,systemId:record.systemId})),
  },
  records:ranked, quarantine, tombstones:[],
  coverage:{allowlistedSystems:sourceRegistry.systems.length,parsedRecords:ranked.length,quarantinedRecords:quarantine.length,vendors:[...new Set(ranked.map((record)=>record.vendor))].sort(),acceleratorFamilies:[...new Set(ranked.map((record)=>record.acceleratorSlug))].sort(),minimumAcceptanceMet:ranked.length>=3&&new Set(ranked.map((record)=>record.vendor)).size>=2},
  sourceManifest:sourceManifest.sort((a,b)=>a.path.localeCompare(b.path)),
};
const datasetHash=sha256(JSON.stringify(datasetCore));
const dataset={...datasetCore,datasetHash};
const artifacts={
  "dataset.json":dataset,
  "manifest.json":{datasetVersion:dataset.datasetVersion,datasetHash,pinnedCommit:commit,sourceManifest:dataset.sourceManifest},
  "coverage-matrix.json":{sliceId,workload:sourceRegistry.workload,scenario:sourceRegistry.scenario,accuracyTarget:sourceRegistry.accuracyTarget,metricId:sourceRegistry.metricId,...dataset.coverage},
  "quarantine-report.json":{datasetVersion:dataset.datasetVersion,count:quarantine.length,records:quarantine},
  "tombstones.json":{datasetVersion:dataset.datasetVersion,tombstones:[]},
  "changelog.json":{datasetVersion:dataset.datasetVersion,changes:["Initial immutable slice","Three verified submitted systems","One deliberately ambiguous fixture quarantined"]},
};

const expectedPath=path.join(root,"data/expected-hashes.json");
if (verify) {
  const expected=await loadJson("data/expected-hashes.json");
  if(expected[mode]!==datasetHash) throw new Error(`${mode} hash mismatch: expected ${expected[mode]}, received ${datasetHash}`);
  const committed=await loadJson("data/generated/dataset.json");
  if(committed.datasetHash!==datasetHash||JSON.stringify(committed)!==JSON.stringify(dataset)) throw new Error("Generated dataset differs from the committed snapshot");
  console.log(`Verified ${mode}: ${ranked.length} published, ${quarantine.length} quarantined; ${datasetHash}`);
} else {
  const generated=path.join(root,"data/generated");
  const staging=path.join(root,`data/.generated-${process.pid}`);
  await rm(staging,{recursive:true,force:true}); await mkdir(staging,{recursive:true});
  for(const [name,value] of Object.entries(artifacts)) await writeFile(path.join(staging,name),`${JSON.stringify(value,null,2)}\n`);
  await mkdir(generated,{recursive:true});
  for(const name of Object.keys(artifacts)) await rename(path.join(staging,name),path.join(generated,name));
  await rm(staging,{recursive:true,force:true});
  let expected={fixture:datasetHash,"full-source":datasetHash};
  try{expected={...await loadJson("data/expected-hashes.json"),[mode]:datasetHash};}catch(error){if(error?.code!=="ENOENT") throw error;}
  await writeFile(expectedPath,`${JSON.stringify(expected,null,2)}\n`);
  console.log(`Promoted ${mode}: ${ranked.length} published, ${quarantine.length} quarantined; ${datasetHash}`);
}

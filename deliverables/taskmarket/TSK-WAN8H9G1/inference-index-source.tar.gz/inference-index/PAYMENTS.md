# x402 payment guide

The API uses `@lucid-agents/payments@5.0.0` through the same runtime that owns discovery and invocation.

## Commercial operations

- `rank-inference-chips`: $0.02 per invoke.
- `compare-inference-chips`: $0.03 per invoke.
- Network: Base Sepolia (`eip155:84532`).
- Scheme: x402 exact USDC.

An unpaid request receives HTTP 402 and the canonical `PAYMENT-REQUIRED` challenge. Lucid verifies and settles a valid credential through the configured facilitator before returning a paid success. No private key is needed by the seller runtime; the public `payTo` destination is discovery metadata.

## Fail-closed behavior

`createInferenceAgent({ paymentConfig: false })` builds the free status and preview operations without payment infrastructure. Priced operations remain priced and are not made free. Deployment uses an explicit Base Sepolia configuration. Mainnet is out of scope.

## Test safely

Do not use mainnet funds. An unpaid smoke request is sufficient to verify the challenge:

```bash
curl -i -X POST "$ORIGIN/api/agent/entrypoints/rank-inference-chips/invoke" \
  -H 'content-type: application/json' \
  -d '{"input":{"sliceId":"mlperf-v6.0/closed/gpt-oss-120b/offline/default-accuracy/tokens-per-second"}}'
```

Expect 402, price `20000` atomic test-USDC units, network `eip155:84532`, and the configured public destination. Never commit payer credentials or facilitator authentication.

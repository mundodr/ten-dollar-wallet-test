"use client";

import { useMemo, useState } from "react";
import type { ResultRecord } from "@/lib/dataset";

const number = new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 });

export function LeaderboardExplorer({ records }: { records: ResultRecord[] }) {
  const [vendor, setVendor] = useState("All vendors");
  const [submitter, setSubmitter] = useState("All submitters");
  const [metricView, setMetricView] = useState<"official"|"per-accelerator">("official");
  const [query, setQuery] = useState("");
  const vendors = ["All vendors", ...Array.from(new Set(records.map((record) => record.vendor)))];
  const submitters = ["All submitters", ...Array.from(new Set(records.map((record) => record.submitter)))];
  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return records.filter((record) =>
      (vendor === "All vendors" || record.vendor === vendor) &&
      (submitter === "All submitters" || record.submitter === submitter) &&
      (!needle || `${record.vendor} ${record.accelerator} ${record.systemName}`.toLowerCase().includes(needle))
    );
  }, [records, vendor, submitter, query]);
  const shownValue = (record:ResultRecord) => metricView === "official" ? record.officialValue : record.derivedPerAcceleratorValue;
  const maximum = Math.max(...filtered.map(shownValue), 1);

  return (
    <section className="board-shell" id="leaderboard" aria-labelledby="board-title">
      <div className="board-head">
        <div>
          <p className="eyebrow">Comparable slice 01</p>
          <h2 id="board-title">Offline throughput</h2>
          <p className="muted">MLPerf Inference v6.0 · Closed · gpt-oss-120b · higher is better</p>
        </div>
        <div className="board-tools">
          <label><span className="sr-only">Workload</span><select aria-label="Workload" defaultValue="gpt-oss-120b"><option>gpt-oss-120b</option></select></label>
          <label><span className="sr-only">Scenario</span><select aria-label="Scenario" defaultValue="Offline"><option>Offline</option></select></label>
          <label><span className="sr-only">Accuracy target</span><select aria-label="Accuracy target" defaultValue="Default accuracy"><option>Default accuracy</option></select></label>
          <label>
            <span className="sr-only">Filter by vendor</span>
            <select value={vendor} onChange={(event) => setVendor(event.target.value)}>
              {vendors.map((item) => <option key={item}>{item}</option>)}
            </select>
          </label>
          <label><span className="sr-only">Filter by submitter</span><select value={submitter} onChange={(event)=>setSubmitter(event.target.value)}>{submitters.map((item)=><option key={item}>{item}</option>)}</select></label>
          <label><span className="sr-only">Metric view</span><select value={metricView} onChange={(event)=>setMetricView(event.target.value as "official"|"per-accelerator")}><option value="official">Official system</option><option value="per-accelerator">Derived / accelerator</option></select></label>
          <label className="search-field">
            <span className="sr-only">Search systems</span>
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search system or chip" />
          </label>
        </div>
      </div>

      {filtered.length ? (
        <div className="table-wrap">
          <table>
            <caption className="sr-only">Ranked MLPerf gpt-oss-120b offline throughput results</caption>
            <thead><tr><th>Rank</th><th>System</th><th>Accelerators</th><th>Accuracy</th><th className="metric-cell">Tokens / second</th><th>Evidence</th></tr></thead>
            <tbody>
              {filtered.map((record) => (
                <tr key={record.logicalId}>
                  <td><span className={`rank rank-${record.rank}`}>{String(record.rank).padStart(2, "0")}</span></td>
                  <td><strong>{record.vendor}</strong><span className="subline">{record.systemName}</span></td>
                  <td>{record.accelerator}<span className="subline">{record.acceleratorCount}× · {record.operatingSystem}</span></td>
                  <td>{record.accuracy.toFixed(2)}%<span className="status-valid">VALID</span></td>
                  <td className="metric-cell"><strong>{number.format(shownValue(record))}</strong><span className="subline">{metricView === "official" ? "official submitted system" : `derived ÷ ${record.acceleratorCount} accelerators`}</span><span className="metric-bar" style={{"--bar": `${Math.max(2, shownValue(record) / maximum * 100)}%`} as React.CSSProperties} /></td>
                  <td><a className="evidence-link" href={record.provenance[1].url} target="_blank" rel="noreferrer">Source ↗</a><span className="subline hash">{record.contentVersionId.slice(0, 8)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="empty-state"><span>∅</span><h3>No comparable results</h3><p>The current filters produce no systems inside this exact benchmark slice.</p><button onClick={() => {setVendor("All vendors");setSubmitter("All submitters");setQuery("");}}>Reset filters</button></div>
      )}
      <div className="board-foot">
        <p>{filtered.length} of {records.length} normalized records</p>
        <p>Last dataset build · 27 Aug 2026 · deterministic fixture</p>
      </div>
    </section>
  );
}

import Link from "next/link";
import { dataset } from "@/lib/dataset";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div>
        <span className="mark">II</span>
        <p>Independent structure around public MLPerf results.</p>
      </div>
      <div>
        <p className="eyebrow">Dataset fingerprint</p>
        <code>{dataset.datasetHash.slice(0, 16)}…</code>
      </div>
      <div className="footer-links">
        <Link href="/methodology">Reproduce</Link>
        <a href={`https://github.com/mlcommons/inference_results_v6.0/tree/${dataset.pinnedCommit}`}>Pinned source ↗</a>
      </div>
    </footer>
  );
}

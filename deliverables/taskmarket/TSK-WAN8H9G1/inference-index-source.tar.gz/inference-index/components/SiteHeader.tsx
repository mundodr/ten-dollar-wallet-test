import Link from "next/link";

const links = [
  ["Leaderboard", "/"],
  ["Methodology", "/methodology"],
  ["API", "/api-docs"],
  ["Updates", "/updates"],
];

export function SiteHeader() {
  return (
    <header className="site-header">
      <Link href="/" className="wordmark" aria-label="Inference Index home">
        <span className="mark" aria-hidden="true">II</span>
        <span>Inference Index</span>
      </Link>
      <nav aria-label="Primary navigation">
        {links.map(([label, href]) => <Link href={href} key={href}>{label}</Link>)}
      </nav>
      <a className="header-cta" href="/api/agent/entrypoints">Agent endpoints ↗</a>
    </header>
  );
}

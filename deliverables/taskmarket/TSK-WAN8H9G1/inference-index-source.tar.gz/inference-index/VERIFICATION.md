# Verification report

Date: 2026-08-27 UTC

Public preview: <https://inference-index-v6.radearthonline.chatgpt.site>

## Data

- Fixture mode: 3 published records, 1 quarantined fixture.
- Full-source allowlist mode: identical published snapshot.
- Vendors/families: AMD Instinct MI355X, Intel Arc Pro B60, NVIDIA B300 SXM.
- Dataset hash: `14b79625bffc23fa04b427c66d9d898ae8254e13f90c97609191e35a32e825c4`.
- All nine upstream files match checked-in SHA-256 values and immutable commit URLs.

## Commands

```text
npm run data:verify       PASS
npm run data:verify:full  PASS
npm run type-check        PASS
npm run lint              PASS
npm run test:unit         PASS
npm run build             PASS
npm run test:rendered     PASS
```

## Route observations

- `GET /api/agent/health`: 200, version 1.0.0.
- Free preview invoke: 200 with validated provenance-bearing records.
- Unpaid rank invoke: 402 with x402 exact offer, Base Sepolia, 0.02 USDC, correct public destination.
- Human pages: server-rendered home, methodology, API, and updates pages.
- Discovery: health, entrypoints, both agent-card aliases, and OpenAPI return 200. The canonical OASF route is mounted and returns Lucid’s explicit `not_enabled` response because V1 intentionally installs only HTTP and payment extensions.
- Anonymous public checks returned 200 for all four human pages, health, entrypoints, and both agent-card aliases.

The public preview is configured for public access and must remain available for at least seven days after requester review.

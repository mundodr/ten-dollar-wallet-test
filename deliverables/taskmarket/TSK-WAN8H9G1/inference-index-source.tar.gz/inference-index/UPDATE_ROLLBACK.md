# Manual update and rollback runbook

Automated PR creation and automatic publication are intentionally absent.

## Update

1. Create a branch and change `data/source-registry.json` only after reviewing compatible upstream evidence at the pinned commit.
2. Add exact source blobs under `data/fixture-sources/`. Do not edit upstream content.
3. Add reviewed aliases or metric policy explicitly; never add fuzzy runtime identity rules.
4. Run both candidate modes:

   ```bash
   npm run data:build
   npm run data:full
   npm run data:verify
   npm run data:verify:full
   ```

5. Inspect `coverage-matrix.json`, `quarantine-report.json`, `tombstones.json`, `changelog.json`, and every source URL.
6. Bump `datasetVersion` and `lastReviewedAt`; record additions, content-version changes, and removals. A reviewed removal must create a tombstone.
7. Run `npm test`. Commit generated artifacts only when fixture and full-source hashes reproduce.

Promotion writes all candidate artifacts to a staging directory and renames validated files into `data/generated`. A failed parse or schema validation never overwrites the committed snapshot.

## Rollback

1. Identify the last good dataset commit; do not delete history.
2. Revert only the source registries, fixture inputs, expected hashes, and generated artifacts to that reviewed commit.
3. Re-run `npm run data:verify`, `npm run data:verify:full`, and `npm test`.
4. Deploy the new application commit. Confirm `/api/agent/entrypoints/get-dataset-status/invoke` returns the restored dataset hash.
5. Record the rollback and reason in the changelog. Keep tombstones for records intentionally removed from publication.

Never hand-edit `data/generated/dataset.json` or its hash.

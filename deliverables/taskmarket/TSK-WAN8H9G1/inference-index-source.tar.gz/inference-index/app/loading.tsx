export default function Loading() {
  return <div className="loading-state" role="status" aria-live="polite"><span className="loading-mark">II</span><div><p className="eyebrow">Loading exact slice</p><h2>Checking records and provenance…</h2></div></div>;
}

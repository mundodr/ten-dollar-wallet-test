import { agentHandlers } from "@/lib/agent-route";
export const runtime = "edge";
export const GET = (request: Request) => agentHandlers.manifest(request);

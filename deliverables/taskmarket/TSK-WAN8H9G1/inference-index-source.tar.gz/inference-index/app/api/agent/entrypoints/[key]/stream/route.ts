import { agentHandlers } from "@/lib/agent-route";
export const runtime = "edge";
export const POST = (request: Request, context: {params: Promise<{key:string}>}) => context.params.then((params) => agentHandlers.stream(request, params));

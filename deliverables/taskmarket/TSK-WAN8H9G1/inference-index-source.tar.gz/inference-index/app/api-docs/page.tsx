import type { Metadata } from "next";

export const metadata: Metadata = { title: "API", description: "Lucid Agents endpoints for ML inference benchmark records." };

const entries = [
  {name:"get-dataset-status",price:"Free",about:"Version, hash, record coverage, quarantine count, and pinned commit."},
  {name:"preview-inference-chips",price:"Free",about:"A compact preview of the top normalized systems in the canonical slice."},
  {name:"rank-inference-chips",price:"$0.02",about:"Filtered, deterministic ranking with limit/offset pagination and provenance."},
  {name:"compare-inference-chips",price:"$0.03",about:"Pairwise or multi-system gap analysis against the selected leader."},
];

export default function ApiDocsPage() {
  return <div className="content-page">
    <header className="page-intro"><div><p className="eyebrow">Agent interface · 02</p><h1>Evidence,<br/>on request.</h1></div><p className="lede">Four typed entrypoints expose the same canonical dataset used by the human leaderboard. Paid operations advertise x402 on Base Sepolia and fail closed when payment infrastructure is absent.</p></header>
    <div className="content-grid">
      <aside className="side-index">01 Discovery<br/>02 Operations<br/>03 Invoke<br/>04 Payments<br/>05 Schemas<br/>06 States</aside>
      <article className="article-stack">
        <section><h2>Discover the agent</h2><p>Lucid Agents generates health, entrypoint, OpenAPI, and agent-card documents from one runtime definition.</p><code className="codeblock">GET /api/agent/health{"\n"}GET /api/agent/entrypoints{"\n"}GET /api/agent/openapi.json{"\n"}GET /api/agent/.well-known/agent-card.json</code></section>
        <section><h2>Operations</h2><table className="spec-table"><tbody>{entries.map((entry)=><tr key={entry.name}><td>{entry.name}<br/><span className="tag">{entry.price}</span></td><td>{entry.about}</td></tr>)}</tbody></table></section>
        <section><h2>Invoke a free preview</h2><code className="codeblock">{`curl -X POST /api/agent/entrypoints/preview-inference-chips/invoke \\\n+  -H 'content-type: application/json' \\\n+  -d '{"input":{"limit":3}}'`}</code><p>All invocations accept an <code>{`{"input": ...}`}</code> envelope. Schemas are Zod-defined and reflected into OpenAPI.</p></section>
        <section><h2>x402 behavior</h2><p>Ranking and comparison are priced USD decimal operations. The runtime is wired with <code>@lucid-agents/payments@5.0.0</code>. A request without a valid payment receives HTTP 402 with canonical payment requirements when the deployment has facilitator configuration. If payment configuration is missing, the paid capability does not silently become free.</p><div className="callout"><strong>Settlement network</strong><br/>Base Sepolia · <code>eip155:84532</code></div></section>
        <section><h2>Rank input</h2><code className="codeblock">{`{
  "input": {
    "sliceId": "mlperf-v6.0/closed/gpt-oss-120b/offline/default-accuracy/tokens-per-second",
    "vendors": ["AMD", "Intel", "NVIDIA"],
    "limit": 25,
    "offset": 0
  }
}`}</code><h3>Compare input</h3><code className="codeblock">{`{
  "input": {
    "sliceId": "mlperf-v6.0/closed/gpt-oss-120b/offline/default-accuracy/tokens-per-second",
    "acceleratorSlugs": ["nvidia-b300-sxm", "amd-instinct-mi355x"],
    "baselineSlug": "amd-instinct-mi355x"
  }
}`}</code></section>
        <section><h2>Response and error states</h2><p>The transport uses Lucid’s canonical envelope and error contract. Absence of evidence is never represented as a zero result.</p><div className="state-grid">
          <div><span className="state-dot loading"/><strong>Loading</strong><p>Manifest or slice is being resolved.</p></div>
          <div><span className="state-dot empty"/><strong>No comparable results</strong><p>Valid filters, zero rows in the exact slice.</p></div>
          <div><span className="state-dot partial"/><strong>Partial evidence</strong><p>Known result returned; missing detail is named.</p></div>
          <div><span className="state-dot invalid"/><strong>Invalid filters</strong><p>HTTP 400 with Zod field issues.</p></div>
          <div><span className="state-dot stale"/><strong>Stale data</strong><p>Manifest exceeds its 30-day review policy.</p></div>
          <div><span className="state-dot payment"/><strong>Payment required</strong><p>HTTP 402 plus a Base Sepolia x402 offer.</p></div>
          <div><span className="state-dot error"/><strong>API error</strong><p>HTTP 500; failure is never reported as success.</p></div>
          <div><span className="state-dot success"/><strong>Paid success</strong><p>Validated output plus settlement headers.</p></div>
        </div><h3>Example successful preview</h3><code className="codeblock">{`{
  "status": "succeeded",
  "output": {
    "sliceId": "mlperf-v6.0/closed/gpt-oss-120b/offline/default-accuracy/tokens-per-second",
    "datasetVersion": "2026.08.27-mlperf-v6.0-gpt-oss-120b-offline.1",
    "records": [{ "rank": 1, "acceleratorSlug": "nvidia-b300-sxm", "displayedValue": 103961 }]
  }
}`}</code></section>
      </article>
    </div>
  </div>;
}

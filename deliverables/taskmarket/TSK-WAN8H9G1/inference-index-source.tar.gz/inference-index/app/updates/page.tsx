import type { Metadata } from "next";
import { dataset } from "@/lib/dataset";

export const metadata: Metadata = { title: "Updates", description: "Inference Index dataset and product changelog." };

export default function UpdatesPage() {
  return <div className="content-page">
    <header className="page-intro"><div><p className="eyebrow">Release log · 03</p><h1>Changes,<br/>with receipts.</h1></div><p className="lede">Dataset and interface changes are recorded separately. A new rank can only arrive through a new deterministic build.</p></header>
    <div className="content-grid"><aside className="side-index">Dataset releases<br/>Interface releases<br/>Breaking changes</aside><article className="article-stack">
      <section className="update-item"><div className="update-date">27 AUG 2026<br/><span className="tag">Dataset</span></div><div><h2>Initial gpt-oss-120b slice</h2><p>Published three valid Closed / Offline records spanning NVIDIA, AMD, and Intel. Added system, performance, and accuracy provenance for every row. Dataset fingerprint: <code>{dataset.datasetHash.slice(0,16)}…</code></p></div></section>
      <section className="update-item"><div className="update-date">27 AUG 2026<br/><span className="tag">API</span></div><div><h2>Lucid Agent endpoints</h2><p>Added two free discovery operations and two x402-priced analysis operations with typed inputs and outputs. Added deterministic pagination and comparison gaps.</p></div></section>
      <section className="update-item"><div className="update-date">27 AUG 2026<br/><span className="tag">Method</span></div><div><h2>Registries and quarantine</h2><p>Introduced explicit metric, alias, and source registries. Invalid or incomplete inputs now produce structured quarantine entries instead of partial records.</p></div></section>
    </article></div>
  </div>;
}

import { LeaderboardExplorer } from "@/components/LeaderboardExplorer";
import { dataset, records } from "@/lib/dataset";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow"><span className="live-dot" />Dataset online · v6.0</p>
          <h1>Find the fastest verified inference hardware for your workload.</h1>
          <p className="lede">Workload-specific, never universal: a narrow, defensible view of accelerator performance normalized from public MLPerf submissions and pinned to source.</p>
          <div className="hero-actions"><a className="button primary" href="#leaderboard">Explore the ranking ↓</a><a className="button secondary" href="/methodology">Audit the method</a></div>
        </div>
        <aside className="hero-proof" aria-label="Dataset summary">
          <div className="proof-top"><span>Current leader</span><span className="status-valid">VALID</span></div>
          <div className="proof-rank">01</div>
          <p className="proof-name">{records[0].accelerator}</p>
          <p className="proof-value">{records[0].officialValue.toLocaleString()} <small>tok/s</small></p>
          <div className="proof-grid"><div><span>Slice</span><strong>Closed / Offline</strong></div><div><span>Model</span><strong>gpt-oss-120b</strong></div><div><span>Sources</span><strong>{dataset.sourceManifest.length} files</strong></div><div><span>Commit</span><strong>{dataset.pinnedCommit.slice(0, 8)}</strong></div></div>
        </aside>
      </section>

      <section className="manifest-strip" aria-label="Dataset manifest">
        <div><span>Dataset release</span><strong>{dataset.datasetVersion}</strong></div>
        <div><span>Source commit</span><strong>{dataset.pinnedCommit.slice(0,12)}</strong></div>
        <div><span>Last reviewed</span><strong>27 Aug 2026</strong></div>
        <div><span>Freshness</span><strong className="fresh">● Current</strong></div>
        <div><span>Coverage</span><strong>{dataset.records.length} records · {dataset.coverage.vendors.length} vendors</strong></div>
      </section>

      <section className="trust-strip" aria-label="Dataset qualities">
        <div><span>01</span><p><strong>Comparable by design</strong>Release, division, workload, scenario, and metric are fixed.</p></div>
        <div><span>02</span><p><strong>Provenance attached</strong>System, performance, and accuracy files are hashed per record.</p></div>
        <div><span>03</span><p><strong>Machine-queryable</strong>Free previews and paid rank/compare endpoints use Lucid Agents.</p></div>
      </section>

      <LeaderboardExplorer records={records} />

      <section className="after-board">
        <div><p className="eyebrow">Why this exists</p><h2>Benchmark data is public. Decisions are still hard.</h2></div>
        <div className="text-columns"><p>Raw result trees optimize for submission completeness—not procurement questions. Inference Index adds a small, explicit comparability layer without inventing a composite score.</p><p>The initial release is intentionally narrow: one workload, one scenario, one primary metric. Expansion happens only when a new slice can remain internally comparable.</p></div>
      </section>

      <section className="api-ribbon">
        <div><p className="eyebrow">For agents and analysts</p><h2>Query the same canonical records.</h2></div>
        <div className="endpoint-preview"><code>POST /api/agent/entrypoints/<strong>rank-inference-chips</strong>/invoke</code><span>$0.02 · x402</span></div>
        <a className="button light" href="/api-docs">Read API docs →</a>
      </section>
    </>
  );
}

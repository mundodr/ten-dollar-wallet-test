import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import "./globals.css";

const sans = Geist({ variable: "--font-sans", subsets: ["latin"] });
const mono = Geist_Mono({ variable: "--font-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  metadataBase: new URL("https://inference-index-v6.radearthonline.chatgpt.site"),
  title: { default: "Inference Index", template: "%s · Inference Index" },
  description: "Reproducible ML inference leaderboards with evidence attached.",
  icons: { icon: "/favicon.svg" },
  openGraph: { title: "Inference Index", description: "Every rank has a source trail.", images: ["/og.png"] },
};

export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body className={`${sans.variable} ${mono.variable}`}><SiteHeader /><main>{children}</main><SiteFooter /></body></html>;
}

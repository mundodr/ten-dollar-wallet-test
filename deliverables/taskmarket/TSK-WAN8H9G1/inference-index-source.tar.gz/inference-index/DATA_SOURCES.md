# Data sources and evidence contract

## Upstream

- Repository: `mlcommons/inference_results_v6.0`
- Commit: `4d3916ac9cf474b679cdfcf492d43a0559418ad1`
- Division: `closed`
- Initial workload/scenario: `gpt-oss-120b` / `Offline`

The source registry allowlists three submitted systems: AMD `8xMI355X_2xEPYC_9575F`, Intel `1-node-4x-BMG-B60`, and NVIDIA `B300-SXM-270GBx8_TRT`. The fixture files are byte-for-byte blobs from that commit.

Every published result requires:

1. `closed/<submitter>/systems/<system>.json` for submitted-system identity and accelerator count.
2. `.../performance/run_1/mlperf_log_summary.txt` with a finite `Tokens per second` value and `Result is : VALID`.
3. `.../accuracy/accuracy.txt` with a final score.

Every source reference stores repository, commit, path, immutable HTTPS URL, and SHA-256. Every normalized result has a stable logical ID and a content-version SHA-256.

## Entity boundaries

- **Accelerator**: reviewed vendor/model identity and stable slug.
- **Submitted system**: accelerator count, host, software stack, and submitter.
- **Benchmark result**: official metric and evidence attached to a system and exact slice.
- **Comparison slice**: release, division, workload, scenario, accuracy target, metric, and unit.
- **Dataset manifest**: snapshot hash, source hashes, timestamps, and coverage.
- **Tombstone**: reviewed removal retained across releases.

## Official and derived values

`officialValue` is the submitted-system result and determines the default ranking. `derivedPerAcceleratorValue` divides it by the positive source-declared `accelerators_per_node`. The metric registry explicitly permits this derivation for the initial throughput metric. Count is never inferred from a system name.

## Quarantine

Unknown units, invalid numbers, missing validity or accuracy evidence, ambiguous accelerator identity, non-positive/ambiguous accelerator count, duplicate IDs, and incompatible dimensions are excluded as `review-required`. The checked-in ambiguous-count fixture proves the quarantine path without fabricating a public result.

## Coverage statement

The initial snapshot has three valid systems, three vendors, three accelerator families, and one deliberately invalid fixture. It does not claim exhaustive coverage of all eligible v6.0 workloads. Expansion requires a reviewed source-registry change and a new immutable dataset version.

import { createAgent } from "@lucid-agents/core";
import { http } from "@lucid-agents/http";
import { payments } from "@lucid-agents/payments";
import { z } from "zod";
import { compareAccelerators, comparabilityDescription, dataset, rankRecords, sliceId, type Grouping, type MetricView } from "@/lib/dataset";

const network = "eip155:84532" as const;
const defaultPaymentConfig = {
  payTo:"0x4244f335c42ebd82dbd1378a9cb192f582d9ad18" as `0x${string}`,
  facilitatorUrl:"https://x402.org/facilitator",
  network,
  storage:{type:"in-memory" as const},
};
type RuntimeOptions = { paymentConfig?: false|typeof defaultPaymentConfig };

const SourceSchema=z.object({repository:z.string(),commit:z.string().length(40),path:z.string(),url:z.string().url(),sha256:z.string().length(64)});
const PublicRecordSchema=z.object({
  rank:z.number().int().positive(),position:z.number().int().positive(),logicalId:z.string(),contentVersionId:z.string().length(64),vendor:z.string(),submitter:z.string(),systemId:z.string(),systemName:z.string(),
  acceleratorSlug:z.string(),accelerator:z.string(),acceleratorCount:z.number().int().positive(),metricView:z.enum(["official","per-accelerator"]),displayedValue:z.number().nonnegative(),officialSystemValue:z.number().nonnegative(),unit:z.literal("tokens/s"),accuracy:z.number().min(0).max(100),valid:z.literal(true),sources:z.array(SourceSchema).length(3),
});
const commonOutput={sliceId:z.string(),comparabilityDescription:z.string(),datasetVersion:z.string(),datasetHash:z.string().length(64),sourceLinks:z.array(z.string().url())};
const publicRecord=(record:ReturnType<typeof rankRecords>["records"][number])=>({
  rank:record.rank,position:record.position,logicalId:record.logicalId,contentVersionId:record.contentVersionId,vendor:record.vendor,submitter:record.submitter,systemId:record.systemId,systemName:record.systemName,
  acceleratorSlug:record.acceleratorSlug,accelerator:record.accelerator,acceleratorCount:record.acceleratorCount,metricView:record.metricView,displayedValue:record.value,officialSystemValue:record.officialValue,unit:"tokens/s" as const,accuracy:record.accuracy,valid:true as const,sources:record.provenance,
});
const responseBase={sliceId,comparabilityDescription,datasetVersion:dataset.datasetVersion,datasetHash:dataset.datasetHash,sourceLinks:[...new Set(dataset.sourceManifest.map((source)=>source.url))]};

export async function createInferenceAgent(options:RuntimeOptions={}) {
  const paymentConfig=options.paymentConfig===undefined?defaultPaymentConfig:options.paymentConfig;
  return createAgent({name:"Inference Index",version:"1.0.0",description:"Typed, provenance-bearing MLPerf inference rankings and comparisons.",url:"https://inference-index-v6.radearthonline.chatgpt.site/api/agent",type:"website"})
    .use(payments({agentId:"inference-index",config:paymentConfig}))
    .use(http({basePath:"/api/agent",servicePage:false}))
    .addEntrypoint({
      key:"get-dataset-status",description:"Return manifest, freshness, exact slice IDs, coverage, quarantine, and pinned sources.",input:z.object({}),
      output:z.object({datasetVersion:z.string(),datasetHash:z.string().length(64),freshness:z.object({state:z.enum(["current","stale"]),policyDays:z.number()}),lastReviewedAt:z.string(),pinnedCommit:z.string().length(40),counts:z.object({records:z.number().int(),vendors:z.number().int(),accelerators:z.number().int(),quarantined:z.number().int(),tombstones:z.number().int()}),sliceIds:z.array(z.string()),sourceLinks:z.array(z.string().url())}),
      handler:async()=>({output:{datasetVersion:dataset.datasetVersion,datasetHash:dataset.datasetHash,freshness:dataset.freshness as {state:"current"|"stale";policyDays:number},lastReviewedAt:dataset.lastReviewedAt,pinnedCommit:dataset.pinnedCommit,counts:{records:dataset.records.length,vendors:dataset.coverage.vendors.length,accelerators:dataset.entities.accelerators.length,quarantined:dataset.quarantine.length,tombstones:dataset.tombstones.length},sliceIds:dataset.slices.map((slice)=>slice.id),sourceLinks:responseBase.sourceLinks}}),
    })
    .addEntrypoint({
      key:"preview-inference-chips",description:"Return up to five verified rows for an optional exact comparison slice.",
      input:z.object({sliceId:z.literal(sliceId).optional(),limit:z.number().int().min(1).max(5).default(5)}),
      output:z.object({...commonOutput,records:z.array(PublicRecordSchema).max(5)}),
      handler:async({input})=>({output:{...responseBase,records:rankRecords(undefined,input.limit,0,"official","all-systems").records.map(publicRecord)}}),
    })
    .addEntrypoint({
      key:"rank-inference-chips",description:"Rank one exact MLPerf slice with official or clearly derived views, grouping, filters, and bounded pagination.",
      input:z.object({sliceId:z.literal(sliceId),vendors:z.array(z.enum(["AMD","Intel","NVIDIA"])).max(3).optional(),metricView:z.enum(["official","per-accelerator"]).default("official"),grouping:z.enum(["all-systems","best-per-accelerator"]).default("all-systems"),limit:z.number().int().min(1).max(100).default(25),offset:z.number().int().min(0).max(10000).default(0)}),
      output:z.object({...commonOutput,metricView:z.enum(["official","per-accelerator"]),grouping:z.enum(["all-systems","best-per-accelerator"]),total:z.number().int(),offset:z.number().int(),responseBytes:z.number().int().max(1048575),records:z.array(PublicRecordSchema)}),
      price:"0.02",paymentProtocol:"x402",network,
      handler:async({input})=>{
        const result=rankRecords(input.vendors,input.limit,input.offset,input.metricView as MetricView,input.grouping as Grouping);
        const payload={...responseBase,metricView:input.metricView,grouping:input.grouping,total:result.total,offset:input.offset,responseBytes:0,records:result.records.map(publicRecord)};
        const responseBytes=new TextEncoder().encode(JSON.stringify(payload)).byteLength;
        if(responseBytes>=1048576) throw new Error("Proven response-size ceiling exceeded");
        return {output:{...payload,responseBytes}};
      },
    })
    .addEntrypoint({
      key:"compare-inference-chips",description:"Compare 2–8 accelerator slugs in one exact slice against an explicit baseline, with missing-evidence reasons.",
      input:z.object({sliceId:z.literal(sliceId),acceleratorSlugs:z.array(z.string().min(1)).min(2).max(8),baselineSlug:z.string().min(1)}).refine((input)=>input.acceleratorSlugs.includes(input.baselineSlug),{message:"baselineSlug must appear in acceleratorSlugs"}),
      output:z.object({...commonOutput,baselineSlug:z.string(),unit:z.literal("tokens/s"),results:z.array(z.object({acceleratorSlug:z.string(),accelerator:z.string(),vendor:z.string(),officialValue:z.number(),deltaFromBaseline:z.number(),percentDeltaFromBaseline:z.number(),sources:z.array(SourceSchema).length(3)})),missingEvidence:z.array(z.object({acceleratorSlug:z.string(),reason:z.string()}))}),
      price:"0.03",paymentProtocol:"x402",network,
      handler:async({input})=>{
        const comparison=compareAccelerators(input.acceleratorSlugs,input.baselineSlug);
        if(!comparison.baseline) return {output:{...responseBase,baselineSlug:input.baselineSlug,unit:"tokens/s" as const,results:[],missingEvidence:[...comparison.missing,{acceleratorSlug:input.baselineSlug,reason:"Explicit baseline has no verified result in this slice."}]}};
        const baseline=comparison.baseline.officialValue;
        return {output:{...responseBase,baselineSlug:input.baselineSlug,unit:"tokens/s" as const,results:comparison.found.map((record)=>({acceleratorSlug:record.acceleratorSlug,accelerator:record.accelerator,vendor:record.vendor,officialValue:record.officialValue,deltaFromBaseline:record.officialValue-baseline,percentDeltaFromBaseline:(record.officialValue-baseline)/baseline*100,sources:record.provenance})),missingEvidence:comparison.missing}};
      },
    }).build();
}

export const agentRuntime=await createInferenceAgent();

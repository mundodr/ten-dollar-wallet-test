import { agentRuntime } from "@/lib/agent-runtime";

export const agentHandlers = agentRuntime.http.handlers;
export const edgeRuntime = "edge";

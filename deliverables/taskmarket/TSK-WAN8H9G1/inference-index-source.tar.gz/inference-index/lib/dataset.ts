import rawDataset from "@/data/generated/dataset.json";

export type Provenance = { repository:string; commit:string; path:string; sha256:string; url:string };
export type ResultRecord = {
  logicalId:string; contentVersionId:string; vendor:string; submitter:string; systemId:string; systemName:string;
  acceleratorSlug:string; accelerator:string; acceleratorRaw:string; acceleratorCount:number; hostProcessor:string; framework:string;
  operatingSystem:string; officialValue:number; derivedPerAcceleratorValue:number; samplesPerSecond:number; accuracy:number;
  valid:true; position:number; rank:number; provenance:Provenance[];
};
export type MetricView = "official" | "per-accelerator";
export type Grouping = "all-systems" | "best-per-accelerator";

export const dataset = rawDataset;
export const records = rawDataset.records as ResultRecord[];
export const sliceId = rawDataset.slices[0].id;
export const comparabilityDescription = rawDataset.slices[0].description;
const metricValue = (record:ResultRecord, metricView:MetricView) => metricView === "official" ? record.officialValue : record.derivedPerAcceleratorValue;

export function rankRecords(vendors:string[]|undefined, limit:number, offset:number, metricView:MetricView="official", grouping:Grouping="all-systems") {
  let selected = vendors?.length ? records.filter((record)=>vendors.includes(record.vendor)) : records.slice();
  if (grouping === "best-per-accelerator") {
    const best = new Map<string,ResultRecord>();
    for (const record of selected) {
      const current = best.get(record.acceleratorSlug);
      if (!current || metricValue(record,metricView) > metricValue(current,metricView)) best.set(record.acceleratorSlug,record);
    }
    selected=[...best.values()];
  }
  selected.sort((a,b)=>metricValue(b,metricView)-metricValue(a,metricView)||a.logicalId.localeCompare(b.logicalId));
  const positioned=selected.map((record,index)=>({
    ...record, value:metricValue(record,metricView), metricView, position:index+1,
    rank:index>0&&metricValue(record,metricView)===metricValue(selected[index-1],metricView)
      ? selected.slice(0,index).filter((prior)=>metricValue(prior,metricView)>metricValue(record,metricView)).length+1
      : index+1,
  }));
  return {total:positioned.length,records:positioned.slice(offset,offset+limit)};
}

export function compareAccelerators(acceleratorSlugs:string[], baselineSlug:string) {
  const unique=[...new Set(acceleratorSlugs)];
  const found=unique.map((slug)=>records.find((record)=>record.acceleratorSlug===slug)).filter((record):record is ResultRecord=>Boolean(record));
  const missing=unique.filter((slug)=>!found.some((record)=>record.acceleratorSlug===slug)).map((slug)=>({acceleratorSlug:slug,reason:"No verified official result in this exact comparison slice."}));
  const baseline=found.find((record)=>record.acceleratorSlug===baselineSlug);
  return {baseline,found,missing};
}

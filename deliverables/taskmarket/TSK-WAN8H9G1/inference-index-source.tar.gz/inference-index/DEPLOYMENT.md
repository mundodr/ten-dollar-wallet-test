# Deployment runbook

The target is a Cloudflare Worker produced by vinext/OpenNext-compatible tooling and hosted through Sites. `.openai/hosting.json` declares the project; no D1 or R2 binding is required.

Current public preview: <https://inference-index-v6.radearthonline.chatgpt.site>

## Build

```bash
npm ci
npm test
```

The production artifact is `dist/server/index.js`. Keep the existing development process running while validating a separate build.

## Deploy

Use the Sites hosting workflow for this project directory. It performs the build, creates/updates the public Cloudflare-backed preview, and returns the public URL. Do not commit deploy tokens or raw provider output.

## Post-deploy smoke checks

```bash
curl -fsS "$ORIGIN/"
curl -fsS "$ORIGIN/methodology"
curl -fsS "$ORIGIN/api-docs"
curl -fsS "$ORIGIN/updates"
curl -fsS "$ORIGIN/api/agent/health"
curl -fsS "$ORIGIN/api/agent/entrypoints"
curl -fsS "$ORIGIN/api/agent/.well-known/agent-card.json"
```

Invoke the free preview and confirm an unpaid rank call returns 402. Verify the public preview remains available through review and for at least seven days. Roll back by redeploying the last verified application commit, then follow `UPDATE_ROLLBACK.md` for dataset restoration.

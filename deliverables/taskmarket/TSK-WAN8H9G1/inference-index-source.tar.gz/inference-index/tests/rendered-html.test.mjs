import assert from "node:assert/strict";
import { access } from "node:fs/promises";
import test from "node:test";

const builtWorker = new URL("../dist/server/index.js", import.meta.url);
let worker;
try { await access(builtWorker); ({default:worker}=await import(`${builtWorker.href}?test=${process.pid}-${Date.now()}`)); } catch { /* bun test may run before a production build */ }
const env = { ASSETS: { fetch: async () => new Response("Not found", {status:404}) } };
const ctx = { waitUntil() {}, passThroughOnException() {} };
const request = (path, init) => worker.fetch(new Request(`https://index.test${path}`, init), env, ctx);
const builtTest = worker ? test : test.skip;

builtTest("server renders the finished editorial leaderboard without starter metadata", async () => {
  const response = await request("/");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /Find the fastest verified inference hardware for your workload/);
  assert.match(html, /NVIDIA B300 SXM/);
  assert.match(html, /Every rank has a source trail/i);
  assert.doesNotMatch(html, /codex-preview|Your site is taking shape|react-loading-skeleton/);
});

builtTest("methodology, API docs, and update log render", async () => {
  const pages = await Promise.all(["/methodology", "/api-docs", "/updates"].map(async (path) => [path, await request(path)]));
  for (const [path, response] of pages) assert.equal(response.status, 200, path);
});

builtTest("free Lucid Agent operation returns provenance-bearing records", async () => {
  const response = await request("/api/agent/entrypoints/preview-inference-chips/invoke", {
    method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({input:{limit:2}}),
  });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.status, "succeeded");
  assert.equal(body.output.records.length, 2);
  assert.equal(body.output.records[0].sources.length, 3);
});

builtTest("generated stream route is mounted without inventing streaming work", async()=>{
  const response=await request("/api/agent/entrypoints/preview-inference-chips/stream",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({input:{}})});
  assert.ok([400,404,405].includes(response.status));
});

builtTest("paid operation fails closed with canonical x402 challenge", async () => {
  const response = await request("/api/agent/entrypoints/rank-inference-chips/invoke", {
    method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({input:{sliceId:"mlperf-v6.0/closed/gpt-oss-120b/offline/default-accuracy/tokens-per-second"}}),
  });
  assert.equal(response.status, 402);
  const encoded = response.headers.get("payment-required");
  assert.ok(encoded);
  const challenge = JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
  assert.equal(challenge.accepts[0].network, "eip155:84532");
  assert.equal(challenge.accepts[0].amount, "20000");
  assert.equal(challenge.accepts[0].payTo.toLowerCase(), "0x4244f335c42ebd82dbd1378a9cb192f582d9ad18");
});

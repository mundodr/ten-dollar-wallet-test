import assert from "node:assert/strict";
import test from "node:test";
import { createInferenceAgent } from "../lib/agent-runtime";
import { sliceId } from "../lib/dataset";

const invokeRequest=(key:string,input:unknown)=>new Request(`https://free.test/api/agent/entrypoints/${key}/invoke`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({input})});

test("free runtime boots without payment configuration and paid work fails closed",async()=>{
  const runtime=await createInferenceAgent({paymentConfig:false});
  try{
    const status=await runtime.http.handlers.invoke(invokeRequest("get-dataset-status",{}),{key:"get-dataset-status"});
    assert.equal(status.status,200);
    const statusBody=await status.json() as {output:{sliceIds:string[]}};
    assert.deepEqual(statusBody.output.sliceIds,[sliceId]);
    const paid=await runtime.http.handlers.invoke(invokeRequest("rank-inference-chips",{sliceId}),{key:"rank-inference-chips"});
    assert.equal(paid.status,503);
    assert.match(await paid.text(),/payment_configuration_error/);
  } finally { await runtime.close(); }
});

test("preview schema and handler output agree",async()=>{
  const runtime=await createInferenceAgent({paymentConfig:false});
  try{
    const response=await runtime.http.handlers.invoke(invokeRequest("preview-inference-chips",{sliceId,limit:5}),{key:"preview-inference-chips"});
    assert.equal(response.status,200);
    const body=await response.json() as {output:{records:Array<{sources:unknown[]}>}};
    assert.equal(body.output.records.length,3);
    assert.ok(body.output.records.every((record)=>record.sources.length===3));
  } finally { await runtime.close(); }
});

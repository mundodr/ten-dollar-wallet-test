import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);
const dataset = JSON.parse(await readFile(new URL("data/generated/dataset.json", root), "utf8"));
const metrics = JSON.parse(await readFile(new URL("data/metric-registry.json", root), "utf8"));
const hash = (value) => createHash("sha256").update(value).digest("hex");

test("fixture contains a valid three-vendor comparable slice", () => {
  assert.equal(dataset.records.length, 3);
  assert.deepEqual(new Set(dataset.records.map((record) => record.vendor)), new Set(["AMD", "Intel", "NVIDIA"]));
  assert.equal(dataset.coverage.minimumAcceptanceMet, true);
  assert.equal(dataset.quarantine.length, 1);
  assert.equal(dataset.quarantine[0].status, "review-required");
  assert.ok(dataset.records.every((record) => record.valid));
  assert.ok(dataset.records.every((record) => JSON.stringify(record.comparableSlice) === JSON.stringify(dataset.records[0].comparableSlice)));
});

test("rank order is numeric, descending, stable, and paginatable", () => {
  const comparator = (a, b) => b.officialValue - a.officialValue || a.logicalId.localeCompare(b.logicalId);
  const tied = [
    {logicalId:"z", officialValue:2}, {logicalId:"b", officialValue:3}, {logicalId:"a", officialValue:3}, {logicalId:"c", officialValue:1},
  ].sort(comparator);
  assert.deepEqual(tied.map((item) => item.logicalId), ["a", "b", "z", "c"]);
  assert.deepEqual(tied.slice(1, 3).map((item) => item.logicalId), ["b", "z"]);
  assert.deepEqual(dataset.records.map((record) => record.rank), [1,2,3]);
});

test("every record carries immutable and internally consistent provenance", async () => {
  for (const record of dataset.records) {
    assert.equal(record.provenance.length, 3);
    assert.equal(new Set(record.provenance.map((source) => source.path)).size, 3);
    for (const source of record.provenance) {
      const raw = await readFile(new URL(`data/fixture-sources/${source.path}`, root), "utf8");
      assert.equal(hash(raw), source.sha256);
      assert.match(source.url, new RegExp(dataset.pinnedCommit));
    }
  }
});

test("performance logs expose the parsed values and VALID status", async () => {
  for (const record of dataset.records) {
    const performance = record.provenance.find((source) => source.path.includes("performance/run_1"));
    const raw = await readFile(new URL(`data/fixture-sources/${performance.path}`, root), "utf8");
    assert.match(raw, new RegExp(`^Tokens per second:\\s*${record.officialValue}$`, "m"));
    assert.match(raw, /Result is\s*:\s*VALID/);
  }
});

test("identity IDs are unique and content versions are immutable hashes", () => {
  assert.equal(new Set(dataset.records.map((record)=>record.logicalId)).size,dataset.records.length);
  assert.equal(new Set(dataset.records.map((record)=>record.contentVersionId)).size,dataset.records.length);
  assert.equal(new Set(dataset.entities.accelerators.map((accelerator)=>accelerator.slug)).size,dataset.entities.accelerators.length);
  assert.ok(dataset.records.every((record)=>/^[a-f0-9]{64}$/.test(record.contentVersionId)));
});

test("metric registry permits only labelled source-count derivation", () => {
  const metric=metrics.metrics["tokens-per-second"];
  assert.equal(metric.canonicalUnit,"tokens/s");
  assert.equal(metric.winningDirection,"higher-is-better");
  assert.equal(metric.derivationAllowed,true);
  for(const record of dataset.records) assert.equal(record.derivedPerAcceleratorValue,record.officialValue/record.acceleratorCount);
});
